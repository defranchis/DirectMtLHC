from ROOT import *
ROOT.gROOT.LoadMacro("AtlasStyle.C") 
#SetAtlasStyle()
